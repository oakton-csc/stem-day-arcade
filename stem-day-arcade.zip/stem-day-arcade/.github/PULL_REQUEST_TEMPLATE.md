## My game

**Name:**
**Folder:** `games/...`

## Checklist

- [ ] Everything for my game is inside its own folder in `games/`, and I didn't change anyone else's files
- [ ] `game.json` has a title, my name, a one-sentence description, and the controls
- [ ] It runs in a browser with no logins, installs, or outside websites
- [ ] Someone who's never seen it can figure it out in about 2 minutes
- [ ] I played it all the way through at least once
- [ ] It's school-appropriate
